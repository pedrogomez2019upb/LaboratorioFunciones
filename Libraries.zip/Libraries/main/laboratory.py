"""
Solución del laboratorio
"""